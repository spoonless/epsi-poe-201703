package fr.epsi.mastermind;

import static org.junit.Assert.*;

import org.junit.Test;

public class MastermindTest {
	
	@Test
	public void joueCoupGagnant() throws Exception {
		Combinaison code = new Combinaison(Couleur.ROUGE, Couleur.ROUGE, Couleur.ROUGE, Couleur.ROUGE);
		Mastermind mastermind = new Mastermind(code);
		
		ResultatTour tour = mastermind.jouer(code);
		
		assertTrue(tour.isGagnant());
		assertEquals(4, tour.getNbCouleursBienPlacees());
		assertEquals(0, tour.getNbCouleursPresentes());
	}

	@Test
	public void joueCoupAvecUneCouleurBienPlacee() throws Exception {
		Combinaison code = new Combinaison(Couleur.ROUGE, Couleur.ROUGE, Couleur.ROUGE, Couleur.ROUGE);
		Mastermind mastermind = new Mastermind(code);
		
		Combinaison essai = new Combinaison(Couleur.ROUGE, Couleur.JAUNE, Couleur.JAUNE, Couleur.JAUNE);
		ResultatTour tour = mastermind.jouer(essai);
		
		assertFalse(tour.isGagnant());
		assertEquals(1, tour.getNbCouleursBienPlacees());
	}

	@Test
	public void joueCoupAvecQuatreCouleursPresentes() throws Exception {
		Combinaison code = new Combinaison(Couleur.ROUGE, Couleur.BLEU, Couleur.BLANC, Couleur.JAUNE);
		Mastermind mastermind = new Mastermind(code);
		
		Combinaison essai = new Combinaison(Couleur.JAUNE, Couleur.BLANC, Couleur.BLEU, Couleur.ROUGE);
		ResultatTour tour = mastermind.jouer(essai);
		
		assertFalse(tour.isGagnant());
		assertEquals(4, tour.getNbCouleursPresentes());
	}

	@Test
	public void joueCoupAvecUneCouleurPresente() throws Exception {
		Combinaison code = new Combinaison(Couleur.ROUGE, Couleur.JAUNE, Couleur.ROUGE, Couleur.ROUGE);
		Mastermind mastermind = new Mastermind(code);
		
		Combinaison essai = new Combinaison(Couleur.JAUNE, Couleur.VERT, Couleur.VERT, Couleur.VERT);
		ResultatTour tour = mastermind.jouer(essai);
		
		assertFalse(tour.isGagnant());
		assertEquals(0, tour.getNbCouleursBienPlacees());
		assertEquals(1, tour.getNbCouleursPresentes());
	}

	@Test
	public void joueCoupAvecUneCouleurPresenteEtUnCouleurBienPlacee() throws Exception {
		Combinaison code = new Combinaison(Couleur.ROUGE, Couleur.JAUNE, Couleur.VERT, Couleur.ROUGE);
		Mastermind mastermind = new Mastermind(code);
		
		Combinaison essai = new Combinaison(Couleur.VERT, Couleur.JAUNE, Couleur.BLEU, Couleur.BLEU);
		ResultatTour tour = mastermind.jouer(essai);
		
		assertEquals(1, tour.getNbCouleursBienPlacees());
		assertEquals(1, tour.getNbCouleursPresentes());
	}

	@Test
	public void joueCoupAvecDeuxCouleursPresentesEtDeuxCouleursBienPlacees() throws Exception {
		Combinaison code = new Combinaison(Couleur.ROUGE, Couleur.JAUNE, Couleur.VERT, Couleur.ROUGE);
		Mastermind mastermind = new Mastermind(code);
		
		Combinaison essai = new Combinaison(Couleur.ROUGE, Couleur.JAUNE, Couleur.ROUGE, Couleur.VERT);
		ResultatTour tour = mastermind.jouer(essai);
		
		assertEquals(2, tour.getNbCouleursBienPlacees());
		assertEquals(2, tour.getNbCouleursPresentes());
	}

	@Test
	public void joueCoupAvecMemeCouleurPresenteEtBienPlacee() throws Exception {
		Combinaison code = new Combinaison(Couleur.ROUGE, Couleur.ROUGE, Couleur.VERT, Couleur.ROUGE);
		Mastermind mastermind = new Mastermind(code);
		
		Combinaison essai = new Combinaison(Couleur.BLEU, Couleur.ROUGE, Couleur.ROUGE, Couleur.BLEU);
		ResultatTour tour = mastermind.jouer(essai);
		
		assertEquals(1, tour.getNbCouleursBienPlacees());
		assertEquals(1, tour.getNbCouleursPresentes());
	}

	@Test
	public void joueCoupAvecMemeCouleur() throws Exception {
		Combinaison code = new Combinaison(Couleur.BLEU, Couleur.JAUNE, Couleur.VERT, Couleur.ROUGE);
		Mastermind mastermind = new Mastermind(code);
		
		Combinaison essai = new Combinaison(Couleur.ROUGE, Couleur.ROUGE, Couleur.ROUGE, Couleur.ROUGE);
		ResultatTour tour = mastermind.jouer(essai);
		
		assertEquals(1, tour.getNbCouleursBienPlacees());
		assertEquals(0, tour.getNbCouleursPresentes());
	}

	@Test
	public void joueAvecUneCouleurPasPresente() throws Exception {
		Combinaison code = new Combinaison(Couleur.BLEU, Couleur.BLANC, Couleur.FUCHSIA, Couleur.FUCHSIA);
		Mastermind mastermind = new Mastermind(code);
		
		Combinaison essai = new Combinaison(Couleur.BLEU, Couleur.BLANC, Couleur.FUCHSIA, Couleur.ROUGE);
		ResultatTour tour = mastermind.jouer(essai);
		
		assertEquals(3, tour.getNbCouleursBienPlacees());
		assertEquals(0, tour.getNbCouleursPresentes());
	}

	@Test
	public void joueAvecUnCodeGenereAleatoirement() throws Exception {
		Mastermind mastermind = new Mastermind();
		
		Combinaison essai = new Combinaison(Couleur.ROUGE, Couleur.ROUGE, Couleur.ROUGE, Couleur.ROUGE);
		ResultatTour tour = mastermind.jouer(essai);
		
		assertNotNull(tour);
	}
}
