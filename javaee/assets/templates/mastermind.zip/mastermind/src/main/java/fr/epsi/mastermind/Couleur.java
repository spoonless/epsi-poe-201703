package fr.epsi.mastermind;

public enum Couleur {
	ROUGE("#FF0000"), 
	JAUNE("#FFFF00"), 
	VERT("#008000"), 
	BLEU("#0000FF"), 
	ORANGE("#FFA500"), 
	BLANC("#FFFFFF"), 
	VIOLET("#EE82EE"), 
	FUCHSIA("#FF00FF");
	
	private String codeCouleur;
	
	private Couleur(String codeCouleur) {
		this.codeCouleur = codeCouleur;
	}
	
	public String getCodeCouleur() {
		return codeCouleur;
	}
	
	public String getLibelle() {
		return this.name();
	}

}
