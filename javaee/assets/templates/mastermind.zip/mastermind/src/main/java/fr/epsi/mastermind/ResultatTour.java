package fr.epsi.mastermind;

public class ResultatTour {

	private int nbCouleursPresentes;
	private int nbCouleursBienPlacees;

	public ResultatTour(int nbCouleursPresentes, int nbCouleursBienPlacees) {
		this.nbCouleursPresentes = nbCouleursPresentes;
		this.nbCouleursBienPlacees = nbCouleursBienPlacees;
	}

	public boolean isGagnant() {
		return nbCouleursBienPlacees == Combinaison.NB_COULEURS_PAR_COMBINAISON;
	}

	public int getNbCouleursBienPlacees() {
		return nbCouleursBienPlacees;
	}

	public Object getNbCouleursPresentes() {
		return nbCouleursPresentes;
	}
}
