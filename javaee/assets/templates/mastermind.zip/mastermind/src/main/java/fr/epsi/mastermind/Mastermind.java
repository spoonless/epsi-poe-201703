package fr.epsi.mastermind;

public class Mastermind {

	private Combinaison codeSecret;
	
	public Mastermind() {
		this.codeSecret = Combinaison.genererAuHasard();
	}

	public Mastermind(Combinaison codeSecret) {
		this.codeSecret = codeSecret;
	}

	public ResultatTour jouer(Combinaison essai) {
		int nbCouleursPresentes = codeSecret.getNbCouleursPresentes(essai); 
		int nbCouleursBienPlacees = codeSecret.getNbCouleursBienPlacees(essai); 
		
		return new ResultatTour(nbCouleursPresentes, nbCouleursBienPlacees);
	}

}
