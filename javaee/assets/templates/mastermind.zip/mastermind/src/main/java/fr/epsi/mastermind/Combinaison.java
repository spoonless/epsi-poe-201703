package fr.epsi.mastermind;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Combinaison {
	
	public static final int NB_COULEURS_PAR_COMBINAISON = 4;

	private List<Couleur> couleurs;

	public Combinaison(Couleur couleur1, Couleur couleur2, Couleur couleur3, Couleur couleur4) {
		couleurs = Collections.unmodifiableList(Arrays.asList(couleur1, couleur2, couleur3, couleur4));
	}
	
	public List<Couleur> getAsList() {
		return couleurs;
	}
	
	public int getNbCouleursPresentes(Combinaison c) {
		int nbCouleursPresentes = 0;
		List<Couleur> couleursRestantes = new ArrayList<Couleur>();
		couleursRestantes.addAll(this.couleurs);

		for (Couleur couleur : c.couleurs) {
			if (couleursRestantes.contains(couleur)) {
				couleursRestantes.remove(couleur);
				++nbCouleursPresentes;
			}
		}
		
		return nbCouleursPresentes - getNbCouleursBienPlacees(c);
	}

	public int getNbCouleursBienPlacees(Combinaison c) {
		int nbCouleursBienPlacees = 0;
		for (int i = 0; i <  this.couleurs.size(); ++i) {
			if (this.couleurs.get(i) == c.couleurs.get(i)) {
				++nbCouleursBienPlacees;
			}
		}
		return nbCouleursBienPlacees;
	}
	
	@Override
	public String toString() {
		return couleurs.toString();
	}

	public static Combinaison genererAuHasard() {
		Couleur[] couleurs = Couleur.values();
		Random random = new Random();
		
		return new Combinaison(couleurs[random.nextInt(couleurs.length)], 
		                       couleurs[random.nextInt(couleurs.length)], 
		                       couleurs[random.nextInt(couleurs.length)], 
		                       couleurs[random.nextInt(couleurs.length)]);
	}

}
