package fr.epsi;

import java.net.URI;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

@Path("/person")
public class ListPersonResource {
	
	@Resource(name="personDataSource")
	private DataSource dataSource;
	
	@Path("/{id}")
	public PersonResource getPersonResource(@PathParam("id") long id) {
		return new PersonResource(dataSource, id);
	}
	
	@GET
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public List<Person> getAll(@Context UriInfo uriInfo) throws SQLException {
		return new PersonDao(dataSource).getAll();
	}

	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public Response create(@FormParam("prenom") String prenom, @FormParam("nom") String nom, @FormParam("age") int age,
							@Context UriInfo uriInfo) throws SQLException {
		Person person = new Person();
		person.setAge(age);
		person.setNom(nom);
		person.setPrenom(prenom);
		
		String id = new PersonDao(dataSource).create(person);
		URI newUri = uriInfo.getRequestUriBuilder().path(id).build();
		return Response.created(newUri).entity(person).build();
	}

}
