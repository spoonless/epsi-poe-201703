package fr.epsi;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

public class PersonDao {

	private final DataSource dataSource;
	
	public PersonDao(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public List<Person> getAll() throws SQLException {
		try (Connection c = dataSource.getConnection();
			 Statement stmt = c.createStatement();
			 ResultSet rs = stmt.executeQuery("select * from Person")) {
		
			List<Person> persons = new ArrayList<>();
			
			while(rs.next()) {
				persons.add(createPerson(rs));
			}
			return persons;
		}
	}

	public String create(Person person) throws SQLException {
		try (Connection c = dataSource.getConnection();
			PreparedStatement pstmt = c.prepareStatement("insert into Person (firstname, lastname, age, dateCreation) values (?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
			
			pstmt.setString(1,  person.getPrenom());
			pstmt.setString(2, person.getNom());
			pstmt.setInt(3,  person.getAge());
			pstmt.setDate(4, new Date(System.currentTimeMillis()));
			
			pstmt.executeUpdate();
			
			String id = "";
			try(ResultSet rs = pstmt.getGeneratedKeys()) {
				if (rs.next()) {
					id = rs.getString(1);
				}
			}
			return id;
		}
	}

	public Person get(long id) throws SQLException {
		try (Connection c = dataSource.getConnection();
			 PreparedStatement pstmt = c.prepareStatement("select * from Person where id=?")) {
			
			pstmt.setLong(1, id);
			try (ResultSet rs = pstmt.executeQuery()) {
				if (! rs.next()) {
					return null;
				}
				return createPerson(rs);
			}
		}
	}

	public void delete(long id) throws SQLException {
		try (Connection c = dataSource.getConnection();
			 PreparedStatement pstmt = c.prepareStatement("delete from Person where id=?")) {
			
			pstmt.setLong(1, id);
			pstmt.executeUpdate();
		}
	}

	private Person createPerson(ResultSet rs) throws SQLException {
		Person person = new Person();
		person.setNom(rs.getString("firstname"));
		person.setPrenom(rs.getString("lastname"));
		person.setAge(rs.getInt("age"));
		return person;
	}

}

