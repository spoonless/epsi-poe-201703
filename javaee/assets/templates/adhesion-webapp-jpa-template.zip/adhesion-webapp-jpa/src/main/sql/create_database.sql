CREATE DATABASE adhesion;

CREATE TABLE IF NOT EXISTS adhesion.Adherent (
  id int(11) NOT NULL AUTO_INCREMENT,
  email varchar(200) NOT NULL,
  motDePasse varchar(200) NOT NULL,
  siteWeb varchar(200),
  dateAdhesion date NOT NULL,
  PRIMARY KEY (id)
) engine=innodb;

CREATE TABLE IF NOT EXISTS adhesion.Adresse (
  id int(11) NOT NULL AUTO_INCREMENT,
  rue varchar(200) NOT NULL,
  codePostal varchar(20) NOT NULL,
  ville varchar(200),
  adhesionId int(11) NOT NULL,
  CONSTRAINT FOREIGN KEY (adhesionId) REFERENCES adhesion.Adherent(id),
  PRIMARY KEY (id)
) engine=innodb;
