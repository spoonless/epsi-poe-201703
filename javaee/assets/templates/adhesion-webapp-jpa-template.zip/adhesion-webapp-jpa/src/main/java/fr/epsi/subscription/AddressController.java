package fr.epsi.subscription;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named
@RequestScoped
public class AddressController {
	
	@EJB
	private SubscriptionRepository repository;

	private Address address = new Address();
	
	public Address getAddress() {
		return address;
	}
	
	public void add(long subscriptionId) {
		repository.add(subscriptionId, address);
	}
}
