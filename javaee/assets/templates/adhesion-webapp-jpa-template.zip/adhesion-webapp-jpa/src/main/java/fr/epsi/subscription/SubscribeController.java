package fr.epsi.subscription;

import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named
@RequestScoped
public class SubscribeController {
	
	@EJB
	private SubscriptionRepository repository;

	private Subscription subscription = new Subscription();
	
	public Subscription getSubscription() {
		return subscription;
	}
	
	public List<Address> getAddresses() {
		// TODO à implémenter
		return null;
	}
	
	public String subscribe() {
		repository.create(subscription);
		return "subscriptionSuccess";
	}

	public void load(long id) {
		this.subscription = repository.get(id);
	}

	public String update() {
		repository.update(subscription);
		return "subscriptionEdition?faces-redirect=true&id=" + subscription.getId();
	}
}
