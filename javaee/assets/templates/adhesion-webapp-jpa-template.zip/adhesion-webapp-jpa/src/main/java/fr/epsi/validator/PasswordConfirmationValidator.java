package fr.epsi.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator("passwordConfirmationValidator")
public class PasswordConfirmationValidator implements Validator {

	@Override
	public void validate(FacesContext ctx, UIComponent uiComponent, Object value) throws ValidatorException {
		UIInput uiPasswordConfirmationInput = (UIInput) uiComponent;
		UIInput uiPasswordInput = (UIInput) uiComponent.getParent().findComponent("password");
		Object password = uiPasswordInput.getValue();
		
		if (password == null || ! password.equals(value)) {
			throw new ValidatorException(new FacesMessage(uiPasswordConfirmationInput.getValidatorMessage()));
		}
	}

}
