package fr.epsi.subscription;

import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Named
@Stateless
public class SubscriptionRepository {
	
	@PersistenceContext(unitName="subscriptionPersistenceUnit")
	private EntityManager entityManager;

	public Subscription get(long id) {
		return entityManager.find(Subscription.class, id);
	}

	public void create(Subscription s) {
		s.setCreationDate(new Date());
		entityManager.persist(s);
	}
	
	public List<Subscription> getAll() {
		return entityManager.createQuery("select s from Subscription s", Subscription.class).getResultList();
	}

	public void remove(Subscription s) {
		// TODO à implémenter
	}

	public void update(Subscription s) {
		// TODO à implémenter
	}

	public void add(long subscriptionId, Address address) {
		// TODO à implémenter
	}

}
